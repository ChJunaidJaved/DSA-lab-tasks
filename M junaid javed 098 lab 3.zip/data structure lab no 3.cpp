#include<iostream>
using namespace std;
class Node;
Node*head=NULL;
class Node{
public:
	int data;
	Node *next;
	Node(int d){
		data =d;
		next = NULL;
	}
	void insert_at_start(int d){
		Node*newNode=new Node(d);
		newNode->next = head;
		head = newNode;
	}
void insert_at_last(int d){
Node*newNode = new Node(d);
Node*temp=head;
while(temp->next != NULL){

	temp=temp->next;
}
temp->next =newNode;
}
void display()
{
	Node*temp=head;
	while(temp!=NULL){
		cout<<temp->data<<" ";
		temp=temp->next;
	}
	cout<<endl;
}
};
int main() {
	Node n(1);
	n.insert_at_start(3);
	n.display();
	n.insert_at_last(5);
	n.display();
}
	
