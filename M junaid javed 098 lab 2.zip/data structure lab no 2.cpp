#include<iostream>
using namespace std;
void maxnumber(int a[],int n){
	for(int i = 0; i < n; i++) {
    cin >> a[i];
    }
    int max = a[0];
    for(int i = 1; i < n; i++) {
    if(a[i] > max) {
    max = a[i];
}
}
cout << "Maximum value: " << max << endl;
}
int main() {
    static int n = 4;
    int a[n]; 
maxnumber(a,n);  
    return 0;
}
//time complexity = 

