#include <iostream>
using namespace std;
class Node {
public:
    int val;
    Node *next;
};
class SinglyLinkedList {
public:
    Node *head;
    SinglyLinkedList() {
        head = NULL;
    }
    void insert(int value) {
        Node* newNode = new Node();
        newNode->val = value;
        newNode->next = NULL;
        if (!head) {
            head = newNode;
        } else {
            Node* temp = head;
            while (temp->next) temp = temp->next;
            temp->next = newNode;
        }
    }
    void print() {
        Node* temp = head;
        while (temp) {
            cout << temp->val << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};
Node* mergeSinglyLinkedLists(Node* list1, Node* list2) {
    if (!list1) return list2;
    if (!list2) return list1;
    if (list1->val < list2->val) {
        list1->next = mergeSinglyLinkedLists(list1->next, list2);
        return list1;
    } else {
        list2->next = mergeSinglyLinkedLists(list1, list2->next);
        return list2;
    }
}
int main() {
    SinglyLinkedList list1;
    list1.insert(1);
    list1.insert(3);
    list1.insert(5);

    SinglyLinkedList list2;
    list2.insert(2);
    list2.insert(4);
    list2.insert(6);

    Node* mergedHead = mergeSinglyLinkedLists(list1.head, list2.head);
    Node* temp = mergedHead;
    while (temp) {
        cout << temp->val << " ";
        temp = temp->next;
    }
    cout << endl;
    return 0;
}
