#include <iostream>
using namespace std;
class DNode {
public:
    int val;
    DNode *next;
    DNode *prev;
};
class DoublyLinkedList {
public:
    DNode *head;
    DoublyLinkedList() {
        head = NULL;
    }
    void insert(int value) {
        DNode* newNode = new DNode();
        newNode->val = value;
        newNode->next = NULL;
        newNode->prev = NULL;
        if (!head) {
            head = newNode;
        } else {
            DNode* temp = head;
            while (temp->next) temp = temp->next;
            temp->next = newNode;
            newNode->prev = temp;
        }
    }
    void print() {
        DNode* temp = head;
        while (temp) {
            cout << temp->val << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};
DNode* mergeDoublyLinkedLists(DNode* list1, DNode* list2) {
    if (!list1) return list2;
    if (!list2) return list1;
    if (list1->val < list2->val) {
        list1->next = mergeDoublyLinkedLists(list1->next, list2);
    if (list1->next) list1->next->prev = list1;
        return list1;
    } else {
        list2->next = mergeDoublyLinkedLists(list1, list2->next);
    if (list2->next) list2->next->prev = list2;
    return list2;
    }
}
int main() {
    DoublyLinkedList list1;
    list1.insert(1);
    list1.insert(3);
    list1.insert(5);

    DoublyLinkedList list2;
    list2.insert(2);
    list2.insert(4);
    list2.insert(6);

    DNode* mergedHead = mergeDoublyLinkedLists(list1.head, list2.head);
    DNode* temp = mergedHead;
    while (temp) {
        cout << temp->val << " ";
        temp = temp->next;
    }
    cout << endl;
    return 0;
}
