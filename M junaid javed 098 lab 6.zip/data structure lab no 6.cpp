#include <iostream>
using namespace std;
class Node {
public:
    int data;
    Node* next;

    Node(int value) {
        data = value;
        next = NULL;
    }
};
class LinkedList {
public:
    Node* head;
    LinkedList() {
    head = NULL;
    }
    void insertEnd(int value) {
        Node* newNode = new Node(value);
        if (!head) {
        head = newNode;
        return;
        }
        Node* temp = head;
        while (temp->next != NULL) {
        temp = temp->next;
        }
        temp->next = newNode;
    }
    void deleteFirstNode() {
        if (head == NULL) {
        cout << "List is empty!" << endl;
        return;
        }
        Node* temp = head;
        head = head->next;
        delete temp;
    }
    void deleteLastNode() {
        if (head == NULL) {
            cout << "List is empty!" << endl;
            return;
        }
        if (head->next == NULL) {
            delete head;
            head = NULL;
            return;
        }
        Node* temp = head;
        while (temp->next && temp->next->next != NULL) {
        temp = temp->next;
        }
        delete temp->next;
        temp->next = NULL;
    }
    void deleteNthNode(int n) {
        if (head == NULL) {
        cout << "List is empty!" << endl;
        return;
        }
        if (n == 1) {
        deleteFirstNode();
        return;
        }
        Node* temp = head;
        for (int i = 1; temp != NULL && i < n - 1; i++) {
        temp = temp->next;
        }
        if (temp == NULL || temp->next == NULL) {
        cout << "Invalid position!" << endl;
        return;
        }
        Node* toDelete = temp->next;
        temp->next = temp->next->next;
        delete toDelete;
    }
    void deleteCenterNode() {
        if (head == NULL || head->next == NULL) {
        cout << "List is too small to have a center node!" << endl;
        return;
        }
        Node* slow = head;
        Node* fast = head;
        Node* prev = NULL;
        while (fast != NULL && fast->next != NULL) {
        fast = fast->next->next;
        prev = slow;
        slow = slow->next;
        }
        prev->next = slow->next;
        delete slow;
    }
    void printList() {
        if (head == NULL) {
            cout << "List is empty!" << endl;
            return;
        }
        Node* temp = head;
        while (temp != NULL) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

int main() {
    LinkedList list;
    list.insertEnd(10);
    list.insertEnd(20);
    list.insertEnd(30);
    list.insertEnd(40);
    list.insertEnd(50);
    cout << "Original List: ";
    list.printList();
    list.deleteFirstNode();
    cout << "After deleting the first node: ";
    list.printList();
    list.deleteLastNode();
    cout << "After deleting the last node: ";
    list.printList();
    list.deleteNthNode(2);
    cout << "After deleting the 2nd node: ";
    list.printList();
    list.deleteCenterNode();
    cout << "After deleting the center node: ";
    list.printList();
    return 0;
}
