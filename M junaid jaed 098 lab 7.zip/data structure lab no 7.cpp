#include <iostream>
using namespace std;
class Node {
public:
    int data;
    Node* next;
    Node* prev;

    Node(int value) {
        data = value;
        next = NULL;
        prev = NULL;
    }
};
class DoublyLinkedList {
public:
    Node* head;
    Node* tail;

    DoublyLinkedList() {
        head = NULL;
        tail = NULL;
    }
    void insertFirst(int value) {
        Node* newNode = new Node(value);
        if (!head) {
            head = newNode;
            tail = newNode;
        } else {
            newNode->next = head;
            head->prev = newNode;
            head = newNode;
        }
    }
    void insertLast(int value) {
        Node* newNode = new Node(value);
        if (!tail) {
            head = newNode;
            tail = newNode;
        } else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
    }
    void insertNth(int value, int n) {
        if (n <= 0) return;
        Node* newNode = new Node(value);
        if (n == 1) {
            insertFirst(value);
            return;
        }
        Node* temp = head;
        int count = 1;

        while (temp != NULL && count < n - 1) {
            temp = temp->next;
            count++;
        }

        if (temp == NULL) {
            insertLast(value);
        } else {
            newNode->next = temp->next;
            if (temp->next != NULL) {
                temp->next->prev = newNode;
            }
            temp->next = newNode;
            newNode->prev = temp;
        }
    }

    void insertCenter(int value) {
        if (!head) {
            insertFirst(value);
            return;
        }
        Node* slow = head;
        Node* fast = head;
        while (fast != NULL && fast->next != NULL) {
            fast = fast->next->next;
            slow = slow->next;
        }
        Node* newNode = new Node(value);
        newNode->next = slow->next;
        if (slow->next != NULL) {
            slow->next->prev = newNode;
        }
        slow->next = newNode;
        newNode->prev = slow;
    }
    void displayForward() {
        if (!head) {
            cout << "List is empty!" << endl;
            return;
        }
        Node* temp = head;
        while (temp != NULL) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
    void displayReverse() {
        if (!tail) {
            cout << "List is empty!" << endl;
            return;
        }
        Node* temp = tail;
        while (temp != NULL) {
            cout << temp->data << " ";
            temp = temp->prev;
        }
        cout << endl;
    }
};
int main() {
    DoublyLinkedList list;
    list.insertFirst(10);
    list.insertLast(20);
    list.insertLast(30);
    list.insertNth(25, 3);
    list.insertCenter(15);
    cout << "List in forward order: ";
    list.displayForward();
    cout << "List in reverse order: ";
    list.displayReverse();
    return 0;
}
