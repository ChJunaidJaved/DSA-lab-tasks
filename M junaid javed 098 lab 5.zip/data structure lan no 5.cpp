#include <iostream>
using namespace std;
class Node {
public:
    int data;
    Node* next;
    Node(int data) {
    this->data = data;
    this->next = NULL;
    }
};
class SinglyLinkedList {
private:
    Node* head;
public:
    SinglyLinkedList() {
        head = NULL;
    }
    void append(int data) {
        Node* newNode = new Node(data);
        if (!head) {
            head = newNode;
            return;
        }
        Node* lastNode = head;
        while (lastNode->next) {
            lastNode = lastNode->next;
        }
        lastNode->next = newNode;
    }
    void printFirstNode() {
        if (head) {
            cout << "First node: " << head->data << endl;
        } else {
            cout << "List is empty" << endl;
        }
    }
    void printLastNode() {
        if (head) {
        Node* lastNode = head;
        while (lastNode->next) {
        lastNode = lastNode->next;
}
    cout << "Last node: " << lastNode->data << endl;
 } else {
    cout << "List is empty" << endl;
}
    }
    void printNthNode(int n) {
        if (head) {
        Node* currentNode = head;
        int count = 1;
        while (currentNode && count < n) {
        currentNode = currentNode->next;
        count++;
            }
        if (currentNode) {
    cout << "The " << n << "th node is: " << currentNode->data << endl;
    } 
	else {
    cout << "The " << n << "th node does not exist" << endl;
 }
}  
	else {
    cout << "List is empty" << endl;
        }
    }

    void printCenterNode() {
	if (head) {
    Node* slow = head;
    Node* fast = head;
    while (fast && fast->next) {
    slow = slow->next;
    fast = fast->next->next;
}
   cout << "Center node: " << slow->data << endl;
   } 
	 else {
    cout << "List is empty" << endl;
        }
    }
};

int main() {
    SinglyLinkedList llist;
    llist.append(10);
    llist.append(20);
    llist.append(30);
    llist.append(40);
    llist.append(50);
    llist.printFirstNode();
    llist.printLastNode();
    llist.printNthNode(3);
    llist.printCenterNode();

    return 0;
}

