#include <iostream>
using namespace std;
class Node {
public:
    int val;
    Node* next;
};
class CircularLinkedList {
public:
    Node* head;
    CircularLinkedList() {
        head = NULL;
    }
    void insertFirst(int value) {
        Node* newNode = new Node;
        newNode->val = value;
        if (head == NULL) {
            head = newNode;
            newNode->next = head;
        } else {
            Node* temp = head;
            while (temp->next != head) {
            temp = temp->next;
            }
            temp->next = newNode;
            newNode->next = head;
            head = newNode;
        }
    }
    void insertLast(int value) {
        Node* newNode = new Node;
        newNode->val = value;
    if (head == NULL) {
            head = newNode;
            newNode->next = head;
        } else {
            Node* temp = head;
            while (temp->next != head) {
            temp = temp->next;
            }
            temp->next = newNode;
            newNode->next = head;
        }
    }
    void insertNth(int value, int position) {
    if (position == 1) {
        insertFirst(value);
        return;
        }
        Node* newNode = new Node;
        newNode->val = value;
        Node* temp = head;
        int count = 1;
        while (count < position - 1 && temp->next != head) {
            temp = temp->next;
            count++;
}
        if (temp->next == head && count < position - 1) {
            cout << "Position is out of range." << endl;
        return;
        }
        newNode->next = temp->next;
        temp->next = newNode;
}
    void insertCenter(int value) {
        if (head == NULL) {
            insertFirst(value);
            return;
        }
        Node* slow = head;
        Node* fast = head;
        while (fast != head && fast->next != head) {
            fast = fast->next->next;
            slow = slow->next;
        }
        Node* newNode = new Node;
        newNode->val = value;
        newNode->next = slow->next;
        slow->next = newNode;
    }
    void displayForward() {
        if (head == NULL) return;
        Node* temp = head;
        do {
            cout << temp->val << " ";
            temp = temp->next;
        } while (temp != head);
        cout << endl;
    }
    void displayReverse(Node* start) {
        if (start == head && start->next != head) return;
        if (start->next != head) {
            displayReverse(start->next);
        }
        cout << start->val << " ";
    }
    void displayReverseOrder() {
        if (head) {
            displayReverse(head);
            cout << endl;
        }
    }
};
int main() {
    CircularLinkedList list;
    list.insertFirst(1);
    list.insertLast(2);
    list.insertLast(3);
    list.insertLast(4);
    cout << "Circular List in forward order: ";
    list.displayForward();
    list.insertNth(5, 3);
    cout << "Circular List after inserting 5 at 3rd position: ";
    list.displayForward();
    list.insertCenter(6);
    cout << "Circular List after inserting 6 at center: ";
    list.displayForward();
    cout << "Circular List in reverse order: ";
    list.displayReverseOrder();
    return 0;
}
