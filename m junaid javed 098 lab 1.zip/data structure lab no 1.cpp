#include<iostream>
using namespace std;
int main() {
int *ptr;
int a = 10;
ptr = &a;
cout << ptr << endl;
cout << a << endl;
*ptr = 115;
cout << a << endl;
cout << *ptr << endl;
}

