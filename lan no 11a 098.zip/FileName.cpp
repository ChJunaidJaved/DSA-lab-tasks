#include <iostream>
using namespace std;

class Queue {
    string names[100];
    int front, rear;

public:
    Queue() {
        front = -1;
        rear = -1;
    }

    void enqueue(string n) {
        if (rear >= 99) {
            cout << "Queue is full\n";
            return;
        }

        if (front == -1) {
            front = 0;
        }

        rear++;
        names[rear] = n;
    }

    void dequeue() {
        if (front == -1 || front > rear) {
            cout << "Queue is empty\n";
            return;
        }

        cout << "Dequeued: " << names[front] << endl;
        front++;

        if (front > rear) {
            front = rear = -1;
        }
    }

    void display() {
        if (front == -1 || front > rear) {
            cout << "Queue is empty\n";
            return;
        }

        cout << "Queue contents:\n";
        for (int i = front; i <= rear; i++) {
            cout << names[i] << endl;
        }
    }
};

int main() {
    Queue q;
    q.enqueue("Ali");
    q.enqueue("ahmad");
    q.enqueue("Zain");
    q.display();
    q.dequeue();
    q.display();
    return 0;
}
