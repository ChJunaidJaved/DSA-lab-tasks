#include <iostream>
using namespace std;
class Queue {
    int data;
    Queue* next;
public:
    static Queue* front;
    static Queue* rear;

    Queue(int val) {
        data = val;
        next = NULL;
    }
    static void enqueue(int val) {
        Queue* n = new Queue(val);
        if (rear == NULL) {
            front = rear = n;
        }
        else {
            rear->next = n;
            rear = n;
        }
    }

    static void dequeue() {
        if (front == NULL) {
            cout << "Queue is empty\n";
            return;
        }
        Queue* temp = front;
        front = front->next;
        delete temp;
        if (front == NULL) {
            rear = NULL;
        }
    }

    static void display() {
        if (front == NULL) {
            cout << "Queue is empty\n";
            return;
        }
        Queue* temp = front;
        while (temp != NULL) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

Queue* Queue::front = NULL;
Queue* Queue::rear = NULL;

int main() {
    Queue::enqueue(10);
    Queue::enqueue(20);
    Queue::enqueue(30);
    cout << "Queue: ";
    Queue::display();

    Queue::dequeue();
    cout << "Queue after one dequeue: ";
    Queue::display();

    return 0;
}