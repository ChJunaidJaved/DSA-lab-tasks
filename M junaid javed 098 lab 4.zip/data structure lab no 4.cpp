#include<iostream>
using namespace std;
class Node {
public:
    int data;
    Node* next;
    static Node* head;
    Node(int d) {
        data = d;
        next = NULL;
}
    void insert_at_start(int d) {
        Node* newNode = new Node(d);
        newNode->next = head;
        head = newNode;
}
    void insert_at_pos(int pos, int d) {
     if (pos < 1) {
    cout << "invalid pos" << endl;
    return;
        }
    if (pos == 1) {
    insert_at_start(d);
} 
	else {
    Node* newNode = new Node(d);    
	Node* temp = head;
    for (int i = 1; i < pos - 1; i++) {
    temp = temp->next;
    if (temp == NULL) {
    cout << "invalid pos" << endl;
    return;
 }
   }
    newNode->next = temp->next;
    temp->next = newNode;
}
    }
void insert_at_last(int d) {
    Node* newNode = new Node(d);
    if (head == NULL) {
    head = newNode;
}
 else {
    Node* temp = head;
    while (temp->next != NULL) {
    temp = temp->next;
}
temp->next = newNode;
}
    }

void display() {
    Node* temp = head;
    while (temp != NULL) {
   cout << temp->data << " ";
   temp = temp->next;
}
   cout << endl;
    }
};
Node* Node::head = NULL;
int main() {
    Node n(1);
    n.insert_at_start(3);
    n.display();
    n.insert_at_last(5);
    n.display();
    n.insert_at_pos(2, 4);
    n.display();
    return 0;
}

