#include <iostream>
#include <iomanip>
#include <string>
#include<conio.h> 
#include <cstdlib> 
using namespace std;
class Contact {
public:
    string name;
    string phone;
    string email;
    string emergencyContact;
    Contact* next;
    Contact(string n, string p, string e, string ec) {
        name = n;
        phone = p;
        email = e;
        emergencyContact = ec;
        next = nullptr;
    }
};
class StackNode {
public:
    Contact contact;
    StackNode* next;
    StackNode(Contact c) : contact(c), next(nullptr) {}
};
class ContactManager {
private:
    Contact* head;
    StackNode* deletedStack;
public:
    ContactManager() {
        head = nullptr;
        deletedStack = nullptr;
       
    }
    void addContact(string name, string phone, string email, string emergency) {
        Contact* newContact = new Contact(name, phone, email, emergency);
        newContact->next = head;
        head = newContact;
        cout << "Contact added successfully.\n";
    }
    void printHeader() {
        cout << left << setw(20) << setfill(' ') << "Name"
            << setw(20) << "Phone"
            << setw(30) << "Email"
            << setw(20) << "Emergency Contact" << "\n";
        cout << setfill('-') << setw(90) << "-" << "\n";
        cout << setfill(' ');
    }
    void printContact(Contact* c) {
        cout << left << setw(20) << c->name
            << setw(20) << c->phone
            << setw(30) << c->email
            << setw(20) << c->emergencyContact << "\n";
    }
    void displayContacts() {
        if (head == nullptr) {
            cout << "No contacts to display.\n";
            return;
        }
        printHeader();
        Contact* temp = head;
        while (temp) {
            printContact(temp);
            temp = temp->next;
        }
    }
    void searchContact(string name) {
        Contact* temp = head;
        while (temp) {
            if (temp->name == name) {
                cout << "Contact found:\n";
                printHeader();
                printContact(temp);
                return;
            }
            temp = temp->next;
        }
        cout << "Contact not found.\n";
    }
    void deleteContact(string name) {
        Contact* temp = head;
        Contact* prev = nullptr;
        while (temp) {
            if (temp->name == name) {
                if (prev) prev->next = temp->next;
                else head = temp->next;

                StackNode* newStackNode = new StackNode(*temp);
                newStackNode->next = deletedStack;
                deletedStack = newStackNode;

                delete temp;
                cout << "Contact deleted and saved in stack.\n";
                return;
            }
            prev = temp;
            temp = temp->next;
        }
        cout << "Contact not found.\n";
    }
    void restoreContact() {
        if (!deletedStack) {
            cout << "No contact to restore.\n";
            return;
        }
        addContact(
            deletedStack->contact.name,
            deletedStack->contact.phone,
            deletedStack->contact.email,
            deletedStack->contact.emergencyContact
        );
        StackNode* temp = deletedStack;
        deletedStack = deletedStack->next;
        delete temp;
        cout << "Last deleted contact restored.\n";
    }
    void sortContacts() {
        if (!head || !head->next) return;
        bool swapped;
        do {
            swapped = false;
            Contact* ptr = head;
            while (ptr->next) {
                if (ptr->name > ptr->next->name) {
                    swap(ptr->name, ptr->next->name);
                    swap(ptr->phone, ptr->next->phone);
                    swap(ptr->email, ptr->next->email);
                    swap(ptr->emergencyContact, ptr->next->emergencyContact);
                    swapped = true;
                }
                ptr = ptr->next;
            }
        } while (swapped);
        cout << "Contacts sorted by name.\n";
    }
    void delay(int milliseconds) {
        for (long long i = 0; i < milliseconds * 10000; ++i) {
            //wait
        }
    }
    void typewriterPrint(const string& text, int delayTime = 5) {
        for (char ch : text) {
            cout << ch << flush;
            delay(delayTime);
        }
        cout << endl;
    }
};
int main() {
    ContactManager manager;
    string message = "=====================================\n"
        " Welcome to Our Contact Application!\n"
        "=====================================\n";
    manager.typewriterPrint(message, 500);
    cout << "\n\nPress enter to continue...";
    cin.get();
    int choice;
    string name, phone, email, emergency;
    while (true) {
        system("cls"); // Clear screen

        cout << "\n--- Contact Manager Menu ---\n";
        cout << "1. Add Contact\n";
        cout << "2. Display Contacts\n";
        cout << "3. Search Contact\n";
        cout << "4. Delete Contact\n";
        cout << "5. Restore Last Deleted\n";
        cout << "6. Sort Contacts by Name\n";
        cout << "7. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore();

        system("cls");

        switch (choice) {
        case 1:
            cout << "Enter Name: "; getline(cin, name);
            cout << "Enter Phone: "; getline(cin, phone);
            cout << "Enter Email: "; getline(cin, email);
            cout << "Enter Emergency Contact: "; getline(cin, emergency);
            manager.addContact(name, phone, email, emergency);
            break;
        case 2:
            manager.displayContacts();
            break;
        case 3:
            cout << "Enter name to search: "; getline(cin, name);
            manager.searchContact(name);
            break;
        case 4:
            cout << "Enter name to delete: "; getline(cin, name);
            manager.deleteContact(name);
            break;
        case 5:
            manager.restoreContact();
            break;
        case 6:
            manager.sortContacts();
            break;
        case 7:
            cout << "Exiting...\n";
            return 0;
        default:
            cout << "Invalid choice.\n";
        }

        cout << "\nPress any key to continue...";
        _getch();
    }
    return 0;
}